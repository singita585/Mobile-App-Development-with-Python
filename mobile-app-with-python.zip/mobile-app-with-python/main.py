from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.uix.screenmanager import Screen
from kivymd.uix.menu import MDDropdownMenu
from kivymd.uix.dialog import MDDialog
from kivy.uix.button import Button
from kivy.uix.label import Label
import sqlite3
import random

class App(MDApp):

    def build(self):
        self.theme_cls.theme_style = "Light"
        self.category = ""
        self.dialog = None
        q = """
        CREATE TABLE if not exists SAVED (
            category text, 
            left text, 
            right text, 
            unique (category,left,right)
        )"""
        self.query_db(q)
        return Builder.load_file("components.kv")

    def query_db(self, q, data=False):
        conn = sqlite3.connect("db.db")
        db = conn.cursor()
        db.execute(q)
        if data:
            lst_tuples_rows = db.fetchall()
        conn.commit()
        conn.close()
        return lst_tuples_rows if data else None

    def dropdown_save(self):
        lst_categories = [i[0] for i in self.query_db(q="SELECT DISTINCT category FROM SAVED", data=True)]
        items = [{"text": f"{i}",
                  "viewclass": "OneLineListItem",
                  "on_release": lambda x=f"{i}": self.set_item_save(x)
                 } for i in lst_categories]
        self.all_categories = MDDropdownMenu(caller=self.root.get_screen('save').ids.category_dropdown_save, items=items, width_mult=4)
        self.all_categories.open()

    def set_item_save(self, x):
        self.category = x
        self.all_categories.dismiss()
        self.root.get_screen('save').ids.category.text = self.category

    def save_word(self):
        category = self.root.get_screen('save').ids.category.text
        left = self.root.get_screen('save').ids.left_word.text
        right = self.root.get_screen('save').ids.right_word.text

        if category and left and right:
            q = f"INSERT OR IGNORE INTO SAVED VALUES ('{category}', '{left}', '{right}')"
            self.query_db(q)
            self.root.get_screen('save').ids.left_word.text = ""
            self.root.get_screen('save').ids.right_word.text = ""
            self.root.get_screen('save').ids.category.text = ""

    def dropdown_edit(self):
        lst_categories = [i[0] for i in self.query_db(q="SELECT DISTINCT category FROM SAVED", data=True)]
        items = [{"text": f"{i}",
                  "viewclass": "OneLineListItem",
                  "on_release": lambda x=f"{i}": self.set_item_edit(x)
                 } for i in lst_categories]
        self.all_categories = MDDropdownMenu(caller=self.root.get_screen('edit').ids.category_dropdown_edit, items=items, width_mult=4)
        self.all_categories.open()

    def set_item_edit(self, x):
        self.category = x
        self.all_categories.dismiss()
        self.root.get_screen('edit').ids.category.text = self.category
        self.load_words()

    def load_words(self):
        q = f"SELECT left, right FROM SAVED WHERE category='{self.category}'"
        words = self.query_db(q, data=True)
        words_list = "\n".join([f"{left} - {right}" for left, right in words])
        self.root.get_screen('edit').ids.words.text = words_list

    def delete_word(self):
        word_to_delete = self.root.get_screen('edit').ids.word_to_delete.text
        q = f"DELETE FROM SAVED WHERE (category='{self.category}' AND left='{word_to_delete}')"
        self.query_db(q)
        self.root.get_screen('edit').ids.word_to_delete.text = ""
        self.load_words()

    def dropdown_play(self):
        lst_categories = [i[0] for i in self.query_db(q="SELECT DISTINCT category FROM SAVED", data=True)]
        items = [{"text": f"{i}",
                  "viewclass": "OneLineListItem",
                  "on_release": lambda x=f"{i}": self.set_item_play(x)
                 } for i in lst_categories]
        self.all_categories = MDDropdownMenu(caller=self.root.get_screen('play').ids.category_dropdown_play, items=items, width_mult=4)
        self.all_categories.open()

    def set_item_play(self, x):
        self.category = x
        self.all_categories.dismiss()
        self.root.get_screen('play').ids.category.text = self.category
        self.play_game()

    def play_game(self):
        q = f"SELECT left, right FROM SAVED WHERE category='{self.category}'"
        words = self.query_db(q, data=True)
        if words:
            random.shuffle(words)
            self.left_word, self.right_word = words[0]
            self.root.get_screen('play').ids.word_to_guess.text = self.left_word
        else:
            self.root.get_screen('play').ids.word_to_guess.text = "No words saved"

    def check_answer(self):
        answer = self.root.get_screen('play').ids.user_answer.text
        if answer == self.right_word:
            result = "Correct!"
        else:
            result = f"Wrong! Correct answer: {self.right_word}"
        self.root.get_screen('play').ids.result.text = result
        self.play_game()

class IntroScreen(Screen):
    pass

class HomeScreen(Screen):
    pass

class PlayScreen(Screen):
    pass

class SaveScreen(Screen):
    pass

class EditScreen(Screen):
    pass

if __name__ == "__main__":
    App().run()
